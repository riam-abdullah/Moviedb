package com.nanodegree.movietime.data.model;

public interface OnItemClickListener {
    void onItemClick( int position);
}
